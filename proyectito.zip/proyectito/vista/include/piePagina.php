<!-- Footer for the Website -->
<footer class="page-footer deep-purple darken-2">
<div class="container">
  <div class="row">
    <div class="col l6 s12">
      <h5 class="white-text">Grupo 2</h5>
			<ul>
        <li>Mauricio Arroyo</li>
        <li>Alvaro Flores</li>
        <li>Uriel Tejeiro</li>
        <li>Anahi Yucra</li>
      </ul>
    </div>
  </div>
</div>

<div class="footer-copyright">
  <div class="container">
  © 2020 Copyright Desarrollo de Aplicaciones Web
  </div>
</div>
</footer>
