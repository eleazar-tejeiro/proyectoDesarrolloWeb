<?php
include("vista/include/encabezado.php");
include("vista/include/navegadorIzqui.php");
?>
<div class="row">
	<div class="column middle">
		<h2>Bienvenido</h2>
		<p>Bienvenido a Academy123</p>
		<h3>Nuestra Mision</h3>
		<p>El proposito de esta plataforma virtual es el de proveer, tanto a los estudiantes como a los docentes, de un entorno de aprendejizaje.
		   Hemos desarrollado muchas funciones, pero si encuentras algun error o sientes que algo falta, por favor contactanos. Puedes encontrar
		   nuestro e-mail en el footer de la pagina. ¡Esperemos que disfrutes esta plataforma virtual!</p>
	</div>
</div>
<?php
include("vista/include/piePagina.php");
?>
